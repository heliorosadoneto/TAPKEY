#!/bin/sh
# TAPKEY Desktop portátil. Requer python3, openssl, GTK3 e libayatana-appindicator3.
D="$(cd "$(dirname "$0")" && pwd)"
export TAPKEY_AGENT="${TAPKEY_AGENT:-$D/agent/agent.py}"
exec "$D/tapkey_desktop" "$@"
